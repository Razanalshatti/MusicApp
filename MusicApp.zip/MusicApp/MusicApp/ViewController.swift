//
//  ViewController.swift
//  MusicApp
//
//  Created by Razan alshatti on 28/02/2024.
//


import UIKit
import SnapKit

class ViewController: UIViewController {
    let uiVisualEffect = UIVisualEffectView(effect: UIBlurEffect(style: .light))
    let backImageView = UIImageView()
    let profileImageView = UIImageView()
    let titleLable = UILabel()
    let songLabel = UILabel( )
    let progressSlider = UISlider()
    let currentTimeLabel = UILabel()
    let remainingTimeLabel = UILabel()
    let playPauseButton = UIButton()
    let nextTrackButton = UIButton()
    let previousTrackButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create an image view to hold your wallpaper
               let imageView = UIImageView(frame: view.bounds)
               imageView.contentMode = .scaleAspectFill
               imageView.image = UIImage(named: "ADELE21")
               view.addSubview(imageView)
        
        // Apply a blur effect
                let blurEffect = UIBlurEffect(style: .regular) // You can adjust the blur style
                let blurView = UIVisualEffectView(effect: blurEffect)
                blurView.frame = view.bounds
                view.addSubview(blurView)
        
            
            view.addSubview(backImageView)
            view.addSubview(uiVisualEffect)
            backImageView.snp.makeConstraints { make in
                make.edges.equalToSuperview()
            }
            uiVisualEffect.snp.makeConstraints { make in
                make.edges.equalToSuperview()
            }
            view.addSubview(profileImageView)
            view.addSubview(titleLable)
            view.addSubview(songLabel)
            view.addSubview(progressSlider)
            view.addSubview(currentTimeLabel)
            view.addSubview(remainingTimeLabel)
            view.addSubview(playPauseButton)
            view.addSubview(nextTrackButton)
            view.addSubview(previousTrackButton)

            view.backgroundColor = .black
            
            setUpUI()
            setUpConstrains()
        }



    

    func setUpUI(){
        //backImageView.image = UIImage(named: "blur" )
        profileImageView.image = UIImage(named: "ADELE21" )
        titleLable.text = "ADELE21"
        titleLable.font = UIFont.boldSystemFont(ofSize: 20.0)
        titleLable.textColor = .white
        
        songLabel.text = "some one like you"
        songLabel.font = UIFont.systemFont(ofSize: 20)
        songLabel.textColor = .white
        currentTimeLabel.text = "0:00"
        remainingTimeLabel.text = "4:45"
        
        progressSlider.minimumValue = 0
        progressSlider.maximumValue = 100
        progressSlider.value = 0
        progressSlider.tintColor = .gray
        // Set SF Symbols for buttons
        playPauseButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
        previousTrackButton.setImage(UIImage(systemName: "forward.end.fill"), for: .normal)
        nextTrackButton.setImage(UIImage(systemName: "backward.end.fill"), for: .normal)
        
        playPauseButton.tintColor = .white
        previousTrackButton.tintColor = .white
        nextTrackButton.tintColor = .white
        
        // Add action targets for buttons
        playPauseButton.addTarget(self, action: #selector(playPauseButtonTapped), for: .touchUpInside)
        previousTrackButton.addTarget(self, action: #selector(nextTrackButtonTapped), for: .touchUpInside)
        nextTrackButton.addTarget(self, action: #selector(previousTrackButtonTapped), for: .touchUpInside)
        
    }

           @objc func playPauseButtonTapped() { }

           @objc func nextTrackButtonTapped() { }

           @objc func previousTrackButtonTapped() { }

    func setUpConstrains( ){
     
            backImageView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
            profileImageView.snp.makeConstraints { make in
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)
            make.top.equalTo( view.safeAreaLayoutGuide.snp.top).offset(180)
            //make.right.equalToSuperview().offset(-15)
            make.height.width.equalTo(250)
        }
        
            titleLable.snp.makeConstraints { make in
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)
            make.bottom.equalTo(profileImageView.snp.bottom).offset(50)
        }
            songLabel.snp.makeConstraints { make in
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)
            make.bottom.equalTo(titleLable.snp.bottom).offset(50)
            //make.centerX.centerY.equalToSuperview()
        }
  
            progressSlider.snp.makeConstraints { make in
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)
            make.bottom.equalTo(songLabel.snp.bottom).offset(30)
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
        }
            
            currentTimeLabel.snp.makeConstraints { make in
            make.leading.equalTo(progressSlider.snp.leading).offset(10)
            make.bottom.equalTo(progressSlider.snp.bottom).offset(20)
            make.centerX.equalTo(progressSlider.snp.centerX).offset(10)
        }
            
            remainingTimeLabel.snp.makeConstraints { make in
            make.trailing.equalTo(progressSlider.snp.trailing).offset(25)
            make.bottom.equalTo(progressSlider.snp.bottom).offset(20)
        }
        // Play/Pause button
            playPauseButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(progressSlider.snp.bottom).offset(20)
        }
        // Next Track button
            nextTrackButton.snp.makeConstraints { make in
            make.centerY.equalTo(playPauseButton)
            make.trailing.equalTo(playPauseButton.snp.leading).offset(-40)
        }
        // Previous Track button
            previousTrackButton.snp.makeConstraints { make in
            make.centerY.equalTo(playPauseButton)
            make.leading.equalTo(playPauseButton.snp.trailing).offset(40)
        }
    }
}
